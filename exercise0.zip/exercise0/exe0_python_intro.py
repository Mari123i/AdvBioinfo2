from typing import Dict, List, Tuple
import numpy as np

AAs: str = 'ALGVSREDTIPKFQNYMHWCUZO'


def get_aa_composition(protein_seq: str) -> Dict[str, int]:
    return {}


def k_mers(alphabet: str, k: int) -> List[str]:
    return []


def get_kmer_composition(protein_seq: str, k: int) -> Dict[str, int]:
    return {}


def get_alignment(protein_seq_1: str, protein_seq_2: str,
                  gap_penalty: int, substitution_matrix: np.ndarray) -> Tuple[str, str]:
    return '', ''

